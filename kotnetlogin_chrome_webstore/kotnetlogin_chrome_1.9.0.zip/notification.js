//Send request for settings and start working
chrome.extension.sendRequest({name: "warning"});