//Add event listeners once the DOM has fully loaded by listening for the
//`DOMContentLoaded` event on the document, and adding your listeners to
//specific elements when it triggers.
document.addEventListener('DOMContentLoaded', function () {

	document.title = chrome.i18n.getMessage('notification_warning');
	var objects = document.getElementsByTagName('*');
	for(var i = 0; i < objects.length; i++) {
		if (objects[i].dataset && objects[i].dataset.message) {
			objects[i].innerHTML = chrome.i18n.getMessage(objects[i].dataset.message);
		}
	}
});